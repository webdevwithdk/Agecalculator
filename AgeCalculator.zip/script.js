let inputDateOfBirth = document.getElementById("inputDob");
inputDateOfBirth.max = new Date().toISOString().split("T")[0];

function calculateAge() {
    let birthDate = new Date(inputDateOfBirth.value);
    let bdate = birthDate.getDate();
    let bmonth = birthDate.getMonth() + 1;
    let byear = birthDate.getFullYear();


    let today = new Date();
    let tdate = today.getDate();
    let tmonth = today.getMonth() + 1;
    let tyear = today.getFullYear();

    let year = tyear - byear;

    if (tmonth > bmonth) {
        month = tmonth - bmonth;
    }
    else {
        year--;
        month = (tmonth + 12) - bmonth;
    };

    if (tdate > bdate) {
        date = tdate - bdate;
    }
    else {
        month--;
        date = (tdate + 30) - bdate;
    }
    document.getElementById("Years").innerHTML = year;
    document.getElementById("Months").innerHTML = month;
    document.getElementById("Days").innerHTML = date;
};
calculateAge();